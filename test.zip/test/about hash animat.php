<html>
    <head>
      <title>Bootstrap Theme Company Page</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
      <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <script>
            $(document).ready(function(){
                $("a[href='#about']").click(function(){
                    if(this.hash !== "")
                    {
                        var hash= this.hash;
                        $("html body").animate(
                                {
                                    scrollTop:$(this.hash).offset().top
                                },
                                1900,
                                function(){
                                    windown.location.hash=hash;
                                })
                    }
                });
            });
      </script>
      <style>
            .carousel-inner > .item > img,
            .carousel-inner > .item > a > img{
            width: 400px;
            height:300px;
            margin: auto;
      </style>
    </head>
    <body>
        <nav class="navbar navbar-default ">
            <div class="navbar-header">
                <a class="navbar-brand"> Bootstrap</a>
            </div>
              <div class="navbar-collapse navbar-right">
                  <ul class="nav navbar-nav">
                      <li><a href="#about">About</a></li>
                  </ul>
              </div>
        </nav>
          <div class="container">
              <div class="row">
                  <div class="col-md-4">
                      <h3>Bootstrap</h3>
                       <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                       
                  </div>
                  <div class="col-md-4">
                      <h3>Bootstrap</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                      
                  </div>
                  <div class="col-md-4">
                      <h3>Bootstrap</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                       
                  </div>
              </div>
              <div class="row">
                  <div class="col-md-4">
                      <h3>Bootstrap</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                       
                  </div>
                  <div class="col-md-4">
                      <h3>Bootstrap</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                       
                  </div>
                  <div class="col-md-4">
                      <h3>Bootstrap</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                       </h4>
                  </div>
              </div>
          </div>
        <div class="container" id="about">
            <div class="text-center">
                <h2>About Us</h2>
                    <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
            <div class="row">
                <div class="col-md-6">
                   
                        <div class="carousel slide" data-ride="carousel">
                            <div id="mycarousel" class="carousel-inner" role="listbox">
                                <div class="item active">
                                    <img src="corporate-1.jpg" height="200px" width="250px">
                                </div>
                                <div class="item">
                                    <img src="corporate-2.jpg" height="200px" width="250px">
                                </div>
                                <div class="item">
                                    <img src="corporate-3.jpg" height="200px" width="250px">
                                </div>
                                <div class="item">
                                    <img src="corporate-4.jpg" height="200px" width="250px">
                                </div>
                            </div>
                            <a href="#mycarousel" class="left carousel-control" data-slide="prev" role="button"> 
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a>
                            <a href="#mycarousel" class="right carousel-control" data-slide="next" role="button">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                            </a>
                        </div>
                   
                </div>
                <div class="col-md-6">
                        <div class="carousel slide" data-ride="carousel">
                            <div id="mycarousel" class="carousel-inner" role="listbox">
                                <div class="item active">
                                    <img src="corporate-5.png" height="200px" width="250px">
                                </div>
                                <div class="item">
                                    <img src="corporate-4.jpg" height="200px" width="250px">
                                </div>
                                <div class="item">
                                    <img src="corporate-7.jpg" height="200px" width="250px">
                                </div>
                                <div class="item">
                                    <img src="corporate-6.jpg" height="200px" width="250px">
                                </div>
                            </div>
                            <a href="#mycarousel" class="left carousel-control" data-slide="prev" role="button"> 
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a>
                            <a href="#mycarousel" class="right carousel-control" data-slide="next" role="button">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                            </a>
                        </div>
                </div>
            </div>
        </div>
          </body>
</html>