<!DOCTYPE html>
<html lang="en">
  <head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="signin.css" rel="stylesheet">
</head>
<body>
    </-------------- Navbar creation ---------------------/>
    
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
        <div class="navbar-header">
            <button class="navbar-toggle" data-toggle="" data-target="" type="button">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="navbar-brand">Logo</a>
        </div>
        <div class=" collapse navbar-collapse" id="navbar-id">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="#about">ABOUT</a></li>
                <li><a href="#">SERVICES</a></li>
                <li><a href="#">PORTFOLIO</a></li>
                <li><a href="#">PRICING</a></li>
                <li><a href="#">CONTACT</a></li>
            </ul>
        </div>
        </div>    
    </nav>
    
    </-------------- jumbotron creation ---------------------/>
    
    <div class="jumbotron text-center">
        <h1 class="comp"> Company </h1>
        <p>We specialize in Web Development</p>
        <div class="container-fluid">
            <form>
            <div class="input-group">
                <input type="email" class="form-control" size="50">
                <div class="input-group-btn">
                    <button class="btn btn-danger">Subscribe</button>
                </div>
                
            </div>
        </form>
        </div>
    </div>
    
    </-------------- ABOUT creation ---------------------/>
    
    <div id="about" class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <h2> About Company </h2><br>
                <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</h4>
                <br><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                <br><a class="btn btn-lg btn-default">Got in Touch</a>
            </div>
            <div class="col-md-4">
                <span class="glyphicon glyphicon-signal logo"></span>
            </div>
        </div>
    </div>
        
    </-------------- SERVICES creation ---------------------/>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <span class="glyphicon glyphicon-globe logo"></span>
            </div>
            <div class="col-md-8">
                <h2>Our Values</h2><br>
                    <h4><strong>MISSION:</strong> Our mission lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</h4><br>
                    <p><strong>VISION:</strong> Our vision Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
        </div>
    </div>
    
    
    </-------------- SERVICES-1 creation ---------------------/>
    
    <div class="container-fluid text-center">
        <h2>SERVICES</h2><br>
        <h4>What We Offer</h4><br><br>
        <div class="row">
            <div class="col-md-4">
                <span class="glyphicon glyphicon-off logo1"></span>
                <br><h3>POWER</h3>
                <br><p>Lorem ipsum dolor sit amet..</p>
            </div>
             <div class="col-md-4">
                <span class="glyphicon glyphicon-heart logo1"></span>
                <br><h3>POWER</h3>
                <br><p>Lorem ipsum dolor sit amet..</p>
            </div>
             <div class="col-md-4">
                <span class="glyphicon glyphicon-lock logo1"></span>
                <br><h3>POWER</h3>
                <br><p>Lorem ipsum dolor sit amet..</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <span class="glyphicon glyphicon-leaf logo1"></span>
                <br><h3>POWER</h3>
                <br><p>Lorem ipsum dolor sit amet..</p>
            </div>
             <div class="col-md-4">
                <span class="glyphicon glyphicon-certificate logo1"></span>
                <br><h3>POWER</h3>
                <br><p>Lorem ipsum dolor sit amet..</p>
            </div>
             <div class="col-md-4">
                <span class="glyphicon glyphicon-wrench logo1"></span>
                <br><h3>POWER</h3>
                <br><p>Lorem ipsum dolor sit amet..</p>
            </div>
        </div>
    </div>
    
    
</body>
<style>
    .logo{
        font-size: 200px;
        color: #f4511e;
    }
    .logo1{
        font-size: 50px;
        color: #f4511e;
    }
    .container-fluid{
        padding-bottom: 60px;
        padding-top: 60px;
        padding-left: 50px;
        padding-right: 50px;
    }
    .navbar{
        background-color: #f4511e;
        color:#fff;
    }
    .jumbotron{
        background-color: #f4511e;
        color:#fff;
    }
    
</style>
</html>



