<html>
    <head>
        <title>Bootstrap Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script>src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
        <script>
            $(document).ready(function(){
                $(".men1").click(function(){
                    //alert("hi");
                    $(".menn1").addClass("col-sm-6");
                    $(".menn1").removeClass("hidden-sm");
                    $(".men10").addClass("hidden-sm");
                    //$(".men0").removeClass("hidden-sm");
                });
                $(".men2").click(function(){
                    //alert("hi");
                    $(".menn2").addClass("col-sm-6");
                    $(".menn2").removeClass("hidden-sm");
                    $(".men20").addClass("hidden-sm");
                    //$(".men0").removeClass("hidden-sm");
                });
            });
        </script>
    </head>
    <body>
        <div class="row">
            <div class="men10 hidden-md hidden-lg col-xs-6 col-sm-6">
                <button class="men1 btn btn-success btn-md">Show</button>
            </div>
            <div class="menn1 col-md-6 col-lg-6 hidden-xs hidden-sm ">
                <nav class="navbar navbar-inverse">
                    <div class="container">
                        <div class="navbar-collapse">
                            <ul class="nav navbar-nav">
                                <li class="active"><a href="#">Home</a> </li>
                                <li><a href="#">About</a> </li>
                                <li><a href="#">Projects</a> </li>
                                <li><a href="#">Contacts</a> </li>
                            </ul>
                        </div>    
                    </div>
                </nav>
            </div>
            <div class=" men20 hidden-md hidden-lg col-xs-6 col-sm-6">
                <button class="men2 btn btn-md btn-success">Show</button>
            </div>
            <div class=" menn2 col-md-6 col-lg-6 hidden-xs hidden-sm">
                <nav class="navbar navbar-inverse">
                    <div class="container">
                        <div class="navbar-collapse">
                            <ul class="nav navbar-nav">
                                <li class="active"><a href="#">Home</a> </li>
                                <li><a href="#">About</a> </li>
                                <li><a href="#">Projects</a> </li>
                                <li><a href="#">Contacts</a> </li>
                            </ul>
                        </div>    
                    </div>
                </nav>
            </div>
        </div>
    </body>
</html>