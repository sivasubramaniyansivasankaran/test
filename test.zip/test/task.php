<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script src="lodash.js"></script>
<script>
$(document).ready(function(){
	var array = [1];
	var other = _.concat(array, 2, [3], [[4]]);
	 
	console.log(other);
	// => [1, 2, 3, [4]]
	 
	console.log(array);
	});
</script>