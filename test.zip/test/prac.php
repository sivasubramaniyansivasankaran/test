<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>Bootstrap Theme Company Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
        .carousel-inner > .item > img,
        .carousel-inner > .item > a > img {
            height:900px;
            width: 100%;
            margin: auto;
         }
         .carousel{
             margin-top:-30px;
         }
  </style>
</head>
<body>
    <nav class="navbar navbar-inverse">
        <div class="container">
            <div class="navbar-header">
                <a href="#" class="navbar-brand"> Bootstrap </a>
            </div>
            <div class="navbar-collapse navbar-right">
                <ul class="nav navbar-nav"> 
                    <li><a href="#">home</a></li>
                    <li><a href="#">brand</a></li>
                    <li><a href="#">tour</a></li>
                    <li><a href="#">contact</a></li>
                    <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">more<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a>Merchandies</a></li>
                            <li><a>Medias</a></li>
                            <li><a>Extras</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        
        <div class="carousel-inner">
            <div class="item active">
                <img src="la.jpg">
                <div class="carousel-caption">
                    <h4>L A</h4>
                    <p>Even though the traffic was a mess, we had the best time playing at Venice Beach!</p>
                </div>
            </div>
            <div class="item">
                <img src="newyork.jpg">
            </div>
            <div class="item">
                <img src="chicago.jpg">
            </div>
        </div>
        
        <a href="#myCarousel" class="left carousel-control" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
        
        <a href="#myCarousel" class="right carousel-control" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
    </div>
</body>
</html>