<html>
    <head>
        <title>Bootstrap Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script type="text/javascript">
                        $(function () {
                            $('#datetimepicker1').datetimepicker();
                        });
        </script>
    </head>
    <body>
        
        <nav class="navbar navbar-inverse navbar-fixed-top">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Bootstrap</a>
                </div>
                <div class="navbar-collapse">
                    <div class="container">
                        <form class="navbar-form navbar-right">
                            <div class="form-group">
                                <input type="text" placeholder="Email" class="form-control">
                            </div>
                            <div class="form-group">
                                <input type="text" placeholder="Password" class="form-control">
                            </div>
                            <button class=" btn btn-md btn-primary"> Login</button>
                        </form>
                    </div>    
                </div>
        </nav>
        <hr>
        <div class="jumbotron">
            <div class="container">
                <h1>Hello Bootstrap</h1>
                <p> Bootstrap is the most popular HTML, CSS and JS Framework...</p>
                <a href="#" class="btn btn-primary btn-lg">Learn More>>></a>
            </div>
        </div>
        <div class="container">
        <div class="row">    
            <div class="col-md-4">
               
                    <h2>Hello Bootstrap</h2>
                    <p>Bootstrap is the most popular HTML, CSS and JS Framework...
                        Bootstrap is the most popular HTML, CSS and JS Framework...
                        Bootstrap is the most popular HTML, CSS and JS Framework...</p>
                    <a href="#" class="btn btn-md btn-default">Learn More>>></a>
            </div>
            <div class="col-md-4">
            
                    <h2>Hello Bootstrap</h2>
                    <p>Bootstrap is the most popular HTML, CSS and JS Framework...
                        Bootstrap is the most popular HTML, CSS and JS Framework...
                        Bootstrap is the most popular HTML, CSS and JS Framework...</p>
                    <a href="#" class="btn btn-md btn-default">Learn More>>></a>
            </div>
            <div class="col-md-4">
                
                    <h2>Hello Bootstrap</h2>
                    <p>Bootstrap is the most popular HTML, CSS and JS Framework...
                        Bootstrap is the most popular HTML, CSS and JS Framework...
                        Bootstrap is the most popular HTML, CSS and JS Framework...</p>
                    <a href="#" class="btn btn-md btn-default">Learn More>>></a>
            </div>
        </div>
            <hr>
            <footer>
            
                <p> @2017 Company, Inc. </p>
            
            </footer>
        </div>
        
    </body>
</html>